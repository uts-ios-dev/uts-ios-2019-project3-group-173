//
//  DoctorMenuVC.swift
//  DoctorsPoint
//
//  Created by Jiajian Liang on 2019/5/16.
//  Copyright © 2019年 UTS. All rights reserved.
//

import Foundation
import UIKit

class DoctorMenuVC: UIViewController {
    
    let myString = StringCollection()
    
    @IBOutlet weak var accountInfoLB: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(_ animated: Bool) {
    }
}
