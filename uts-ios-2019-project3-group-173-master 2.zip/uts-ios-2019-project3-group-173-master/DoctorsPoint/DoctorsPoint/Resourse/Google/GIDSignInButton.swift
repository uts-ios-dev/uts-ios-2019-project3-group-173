//
//  GIDSignInButton.swift
//  DoctorsPoint
//
//  Created by Jiajian Liang on 2019/5/15.
//  Copyright © 2019年 UTS. All rights reserved.
//

import Foundation

class GIDSignInButton {
    //a class for sign in with google button
    //do not edit!
}
