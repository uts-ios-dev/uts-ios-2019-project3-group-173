//
//  CustomColour.swift
//  DoctorsPoint
//
//  Created by Jiajian Liang on 2019/5/20.
//  Copyright © 2019年 UTS. All rights reserved.
//

import Foundation
import UIKit

class CustomColour {
    
    var tsuYukuSa_Blue = UIColor(red: 46, green: 169, blue: 223, alpha: 1)
    
}
