//
//  myString.swift
//  DoctorsPoint
//
//  Created by Jiajian Liang on 2019/5/16.
//  Copyright © 2019年 UTS. All rights reserved.
//

import Foundation

class StringCollection {
    
    var toPatientMainView = "toPatientMainView"
    var toDoctorMainView = "toDoctorMainView"
    var toLoginView = "toLoginView"
    var appointment = "appointment"
    var account = "account"
    var fromPMenutoView = "fromPMenutoView"
    var fromPFormtoView = "fromPFormtoView"
}
